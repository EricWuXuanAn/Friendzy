package com.example.tip102group01friendzy.ui.feature.chat

class Chatroom (
    var id : String,
    var name : String,
    var image: Int
)