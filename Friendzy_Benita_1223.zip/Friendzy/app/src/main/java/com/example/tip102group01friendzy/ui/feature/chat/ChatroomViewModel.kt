package com.example.tip102group01friendzy.ui.feature.chat

class ChatroomViewModel {
}